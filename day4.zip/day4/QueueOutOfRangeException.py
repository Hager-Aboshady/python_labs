class QueueOutOfRangeException(Exception):
 pass

